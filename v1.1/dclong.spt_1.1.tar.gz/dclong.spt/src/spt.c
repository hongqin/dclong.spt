/*
 * spt.c
 *
 *  Created on: Feb 6, 2012
 *      Author: adu
 */


#include <R.h>

#include <Rmath.h>

#include "mean.h"

#include "corr.h"
